from .language_checker import LanguageChecker

languages = LanguageChecker()
