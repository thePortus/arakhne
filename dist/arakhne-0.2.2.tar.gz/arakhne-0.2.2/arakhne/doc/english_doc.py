from .nltk_doc import NLTKDoc


class EnglishDoc(NLTKDoc):
    language = 'english'
