from .nltk_corpus import NLTKCorpus


class EnglishCorpus(NLTKCorpus):
    language = 'english'
